import Header from '@/components/common/Header';
import Oro from '../../components/common/Oro';
import Footer from '@/components/common/Footer';
import ContactForm from '../../components/common/ContactForm';
import { getMessages } from 'next-intl/server';
import { useTranslations } from 'next-intl';

export async function generateMetadata({ params }: { params: { locale: string } }) {
  const messages = await getMessages({ locale: params.locale });

  return {
    title: messages.Products.oroTitle,
    description: messages.Products.oroDescription,
    alternates: {
      canonical: messages.Products.Canonical.oro,
    },
    openGraph: {
      title: messages.Products.oroTitle,
      description: messages.Products.oroDescription,
      type: 'website',
      url: messages.Products.Canonical.oro,
      images: [
        {
          url: messages.Products.OG.oroImage,
          width: 1200,
          height: 630,
          alt: messages.Products.oroTitle,
        },
      ],
    },
  };
}

const Products: React.FC = () => {
  const t = useTranslations('Products');

  return (
    <>
      <h1 className="sr-only">{t('oroH1')}</h1>

      <div className="container mx-auto px-4 md:px-8">
        <Header />
        <Oro />
      </div>
      <div className="container mx-auto px-4 md:px-8">
        <ContactForm />
        <Footer />
      </div>
    </>
  );
};
export default Products;
